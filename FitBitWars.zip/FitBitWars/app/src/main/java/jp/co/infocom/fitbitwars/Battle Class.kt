package jp.co.infocom.fitbitwars

class Battler(val name:String, val id:Int, var hp:Int, val attack:Int, val defence:Int, val speed:Int){

}


//class nowCondition(val player1:Battler ,val player2:Battler ,val turn:Int){
//}